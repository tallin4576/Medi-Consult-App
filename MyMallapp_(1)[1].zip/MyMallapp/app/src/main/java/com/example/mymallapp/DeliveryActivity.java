package com.example.mymallapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class DeliveryActivity extends AppCompatActivity {

    private RecyclerView deliveryrecycler_view;
    private Button change_or_add_newaddressBtn;
    public static final int SELECT_ADDRESS=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setTitle("Delivery");

        deliveryrecycler_view=findViewById(R.id.delivery_recyclerview);
        change_or_add_newaddressBtn= findViewById(R.id.change_or_add_address_btn);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        deliveryrecycler_view.setLayoutManager(layoutManager);


        List<CartItemModel> cartItemModelList=new ArrayList<>();
        cartItemModelList.add(new CartItemModel(0,R.mipmap.phone_2,"Pixel XL 2",2,"Rs.49999/-","Rs.59999/-",1,1,0));
        cartItemModelList.add(new CartItemModel(0,R.mipmap.phone_2,"Pixel XL 2",0,"Rs.49999/-","Rs.59999/-",1,1,0));
        cartItemModelList.add(new CartItemModel(0,R.mipmap.phone_2,"Pixel XL 2",2,"Rs.49999/-","Rs.59999/-",1,1,0));

        cartItemModelList.add(new CartItemModel(1,"Price: (3 Items)","Rs.49999/-","Free","Rs.49999/-","Saved Price : 5999/-"));

        CartAdapter cartAdapter=new CartAdapter(cartItemModelList);
        deliveryrecycler_view.setAdapter(cartAdapter);
        cartAdapter.notifyDataSetChanged();
        change_or_add_newaddressBtn.setVisibility(View.VISIBLE);
        change_or_add_newaddressBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myaddressesIntent=new Intent(DeliveryActivity.this,ActivityMyaddresses.class);
                myaddressesIntent.putExtra("MODE",SELECT_ADDRESS);
                startActivity(myaddressesIntent);

            }
        });
    }
    public boolean onOptionsItemSelected (MenuItem item){
        int id = item.getItemId();

        if(id== android.R.id.home){
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
