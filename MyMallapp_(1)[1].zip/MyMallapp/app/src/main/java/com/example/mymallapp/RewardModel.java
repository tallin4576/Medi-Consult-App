package com.example.mymallapp;

public class RewardModel {

    private String title;
    private String expiry_date;
    private String coupon_body;

    public RewardModel(String title, String expiry_date, String coupon_body) {
        this.title = title;
        this.expiry_date = expiry_date;
        this.coupon_body = coupon_body;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getExpiry_date() {
        return expiry_date;
    }

    public void setExpiry_date(String expiry_date) {
        this.expiry_date = expiry_date;
    }

    public String getCoupon_body() {
        return coupon_body;
    }

    public void setCoupon_body(String coupon_body) {
        this.coupon_body = coupon_body;
    }
}
