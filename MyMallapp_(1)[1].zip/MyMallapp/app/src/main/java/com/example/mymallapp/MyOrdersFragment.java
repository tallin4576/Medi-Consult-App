package com.example.mymallapp;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class MyOrdersFragment extends Fragment {


    public MyOrdersFragment() {
        // Required empty public constructor
    }

    private RecyclerView myOrdersRecyclerView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_my_orders, container, false);

        myOrdersRecyclerView= view.findViewById(R.id.my_orders_recycler_view);
        LinearLayoutManager layoutManager=new LinearLayoutManager(getContext());
        myOrdersRecyclerView.setLayoutManager(layoutManager);

        List<MyOrderItemModel> myOrderItemModelyList=new ArrayList<>();
        myOrderItemModelyList.add(new MyOrderItemModel(R.mipmap.phone_2,2,"PIXEL 2 XL (BLACK)","Delivered on Monday 15th Jan,2020"));
        myOrderItemModelyList.add(new MyOrderItemModel(R.mipmap.phone_1,1,"PIXEL 2 XL (BLACK)","Delivered on Monday 25th Jan,2020"));
        myOrderItemModelyList.add(new MyOrderItemModel(R.mipmap.phone,0,"PIXEL 2 XL (BLACK)","Cancelled"));
        myOrderItemModelyList.add(new MyOrderItemModel(R.mipmap.phone_3,3,"PIXEL 2 XL (BLACK)","Delivered on Monday 30th Jan,2020"));

        MyOrdersAdapter myOrdersAdapter=new MyOrdersAdapter(myOrderItemModelyList);
        myOrdersRecyclerView.setAdapter(myOrdersAdapter);
        myOrdersAdapter.notifyDataSetChanged();
        return view;

    }

}
