package com.example.mymallapp;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyOrdersAdapter extends RecyclerView.Adapter<MyOrdersAdapter.ViewHolder> {

    private List<MyOrderItemModel> myOrderItemModelList;

    public MyOrdersAdapter(List<MyOrderItemModel> myOrderItemModelList) {
        this.myOrderItemModelList = myOrderItemModelList;
    }
    private LinearLayout ratenow_container;

    @NonNull
    @Override
    public MyOrdersAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.my_orderitem_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyOrdersAdapter.ViewHolder holder, int position) {
        int resource=myOrderItemModelList.get(position).getProduct_image();
        int rating=myOrderItemModelList.get(position).getRating();
        String title=myOrderItemModelList.get(position).getProduct_title();
        String delivereddate=myOrderItemModelList.get(position).getDelivery_status();
        holder.setData(resource,title,delivereddate,rating);

    }

    @Override
    public int getItemCount() {
        return myOrderItemModelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private ImageView product_Image;
        private TextView product_Title;
        private TextView delivery_status;
        private ImageView order_indicator;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            product_Image=itemView.findViewById(R.id.product_image);
            product_Title=itemView.findViewById(R.id.product_title);
            order_indicator=itemView.findViewById(R.id.order_indicator);
            delivery_status=itemView.findViewById(R.id.order_delivered_date);
            ratenow_container=itemView.findViewById(R.id.rate_now_container);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent OrderDeatilsIntent=new Intent(itemView.getContext(),OrderDetailsActivity.class);
                    itemView.getContext().startActivity(OrderDeatilsIntent);
                }
            });

        }
        private void setData(int resource,String title,String deliveryDate,int rating) {
            product_Image.setImageResource(resource);
            product_Title.setText(title);
            if (deliveryDate.equals("Cancelled")) {
                order_indicator.setImageTintList(ColorStateList.valueOf(itemView.getContext().getResources().getColor(R.color.colorPrimary)));

            } else {
                order_indicator.setImageTintList(ColorStateList.valueOf(itemView.getContext().getResources().getColor(R.color.successGreen)));

            }
            delivery_status.setText(deliveryDate);
            ratenow_container = itemView.findViewById(R.id.rate_now_container);
            setRating(rating);
            for (int x = 0; x < ratenow_container.getChildCount(); x++) {
                final int starPosition = x;
                ratenow_container.getChildAt(x).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        setRating(starPosition);
                    }
                });
            }
        }
            private void setRating(int starPosition) {

                for(int x=0;x<ratenow_container.getChildCount();x++){
                    ImageView starBtn= (ImageView)ratenow_container.getChildAt(x);
                    starBtn.setImageTintList(ColorStateList.valueOf(Color.parseColor("#bebebe")));
                    if(x <= starPosition){
                        starBtn.setImageTintList(ColorStateList.valueOf(Color.parseColor("#ffbb00")));
                    }
                }
            }
        }
    }

