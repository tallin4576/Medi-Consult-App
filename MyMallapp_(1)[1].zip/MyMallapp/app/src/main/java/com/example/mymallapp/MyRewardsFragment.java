package com.example.mymallapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class MyRewardsFragment extends Fragment {

    public MyRewardsFragment() {
        // Required empty public constructor
    }

    private RecyclerView rewardsRecyclerView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_my_rewards, container, false);
        rewardsRecyclerView=view.findViewById(R.id.my_rewards_recycler_view);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this.getContext());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        rewardsRecyclerView.setLayoutManager(layoutManager);
        rewardsRecyclerView.setHasFixedSize(true);

        List<RewardModel> rewardModelList=new ArrayList<>();
        rewardModelList.add(new RewardModel("CashBack","Till 2nd February,2020","Get 20% cashback on any product above Rs.200/- and below Rs.3000/-"));
        rewardModelList.add(new RewardModel("Discount","Till 2nd February,2020","Get 20% cashback on any product above Rs.200/- and below Rs.3000/-"));
        rewardModelList.add(new RewardModel("Buy 1 get 1 free","Till 2nd February,2020","Get 20% cashback on any product above Rs.200/- and below Rs.3000/-"));
        rewardModelList.add(new RewardModel("Buy 2 get 2 free","Till 2nd February,2020","Get 20% cashback on any product above Rs.200/- and below Rs.3000/-"));
        rewardModelList.add(new RewardModel("CashBack","Till 2nd February,2020","Get 20% cashback on any product above Rs.200/- and below Rs.3000/-"));
        rewardModelList.add(new RewardModel("CashBack","Till 2nd February,2020","Get 20% cashback on any product above Rs.200/- and below Rs.3000/-"));
        rewardModelList.add(new RewardModel("CashBack","Till 2nd February,2020","Get 20% cashback on any product above Rs.200/- and below Rs.3000/-"));
        rewardModelList.add(new RewardModel("CashBack","Till 2nd February,2020","Get 20% cashback on any product above Rs.200/- and below Rs.3000/-"));


        MyRewardsAdapter rewardsAdapter=new MyRewardsAdapter(rewardModelList);
        rewardsRecyclerView.setAdapter(rewardsAdapter);
        rewardsAdapter.notifyDataSetChanged();
        return view;

    }
}
