package com.example.mymallapp;

public class MyOrderItemModel {

    private int product_image;
    private String product_title;
    private String delivery_status;
    private int rating;

    public MyOrderItemModel(int product_image,int rating ,String product_title, String delivery_status) {
        this.product_image = product_image;
        this.rating=rating;
        this.product_title = product_title;
        this.delivery_status = delivery_status;
    }

    public int getProduct_image() {
        return product_image;
    }

    public void setProduct_image(int product_image) {
        this.product_image = product_image;
    }

    public String getProduct_title() {
        return product_title;
    }

    public void setProduct_title(String product_title) {
        this.product_title = product_title;
    }

    public String getDelivery_status() {
        return delivery_status;
    }

    public void setDelivery_status(String delivery_status) {
        this.delivery_status = delivery_status;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
}
